<?php
/*Datos de conexion a la base de datos*/
define('DB_HOST', '4c003ee5a1eb');//DB_HOST:  generalmente suele ser "127.0.0.1"
define('DB_USER', 'root');//Usuario de tu base de datos
define('DB_PASS', 'root');//Contraseña del usuario de la base de datos
define('DB_NAME', 'CS');//Nombre de la base de datos
?>